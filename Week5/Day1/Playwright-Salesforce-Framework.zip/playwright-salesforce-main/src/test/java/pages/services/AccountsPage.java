package pages.services;

import pages.base.SalesforceHooks;

public class AccountsPage extends SalesforceHooks {
	
	public AccountsPage typeAccountName(String accountName) {
		
		typeInputField("Account Name", accountName);
		
		return this;
	}
	
	public AccountsPage typeAccountNumber(String accountNumber) {
		
		typeInputField("Account Number", accountNumber);
		
		return this;
	}
	public AccountsPage chooseRating(String value) {
		
		chooseByText("Rating", value);	
		
		return this;
	}
	
	public AccountsPage clickSave() {
		
		click("//span[text()='Account Information']/following::button[text()='Save']", "Save");	
		return this;
	}
	
	
}
