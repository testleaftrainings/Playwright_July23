package pages.services;

import pages.base.SalesforceHooks;

public class ServiceDashboardPage extends SalesforceHooks {
	
	public ServiceDashboardPage clickTab(String tabName ) {
		
		click("//span[text()='"+tabName+"']", tabName, "Tab");
		
		return this;
	}

	public ServiceDashboardPage clickMenu(String menuName ) {
		
		click("//div[@title='"+menuName+"']", menuName, "Menu");
		
		return this;
	}
}
