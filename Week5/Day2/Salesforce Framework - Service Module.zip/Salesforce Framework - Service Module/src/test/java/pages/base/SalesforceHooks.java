package pages.base;

import org.testng.annotations.BeforeMethod;

import com.force.base.ProjectHooks;

public class SalesforceHooks extends ProjectHooks{
	
	@BeforeMethod
	public void zLogin() {
		
		new LoginPage().doLogin();
	}
	
	public void typeInputField(String label, String value) {
		
		type("(//label[text()='"+label+"']/following::input)[1]",value,label );
	}
	
	public void chooseByText(String label, String value) {
		
		clickAndChoose("//label[text()='"+label+"']/following::lightning-base-combobox[1]", "//label[text()='"+label+"']/following::span[text()='"+value+"']", value, label);
	}
}
