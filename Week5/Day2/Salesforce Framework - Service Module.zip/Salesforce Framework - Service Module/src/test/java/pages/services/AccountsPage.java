package pages.services;

import com.force.data.dynamic.FakerDataFactory;

import pages.base.SalesforceHooks;

public class AccountsPage extends SalesforceHooks {
	
	public AccountsPage typeAccountName() {
		
		typeInputField("Account Name", FakerDataFactory.getFirstName());
		
		return this;
	}
	
	public AccountsPage typeAccountNumber() {
		
		typeInputField("Account Number", FakerDataFactory.getBankAccountNumber());
		
		return this;
	}
	public AccountsPage chooseRating() {
		
		chooseByText("Rating", FakerDataFactory.getRating());	
		
		return this;
	}
	
	public AccountsPage clickSave() {
		
		click("(//button[text()='Save'])[1]", "Save");	
		return this;
	}
	
	
}
