package tests.ui.services;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.base.HomePage;
import pages.base.SalesforceHooks;
import pages.services.AccountsPage;
import pages.services.ServiceDashboardPage;

public class TC01_CreateAccount extends SalesforceHooks {
	
	@BeforeTest
	public void setReportValues() {
		
		testcaseName = "TC01_CreateAccount";
		testDescription = "Create New Account with mandatory fields";
		authors = "Ranjini";
		category= "Service";
	}
	
	@Test
	public void createAccount() {
		
		new HomePage()
		.clickAppLauncher()
		.clickViewAll()
		.typeSearchApp("Service")
		.clickApp("Service");
		
		new ServiceDashboardPage()
		.clickTab("Accounts")
		.clickMenu("New");
		
		new AccountsPage()
		.typeAccountName()
		.typeAccountNumber()
		.chooseRating()
		.clickSave();
		
		
	}

}
