package tests.ui.services;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.base.HomePage;
import pages.base.SalesforceHooks;
import pages.services.AccountsPage;
import pages.services.ServiceDashboardPage;

public class TC02_EditAccount extends SalesforceHooks {
	
	@BeforeTest
	public void setReportValues() {
		
		testcaseName = "TC02_EditAccount";
		testDescription = "Edit existing Account with rating change";
		authors = "Ranjini";
		category= "Service";
	}
	
	@Test
	public void editAccount() {
		
		new HomePage()
		.clickAppLauncher()
		.clickViewAll()
		.typeSearchApp("Service")
		.clickApp("Service");
		
		new ServiceDashboardPage()
		.clickTab("Accounts")
		.typeSearch("Ranjini")
		.clickAction()
		.clickEdit();
		
		
		new AccountsPage()
		.chooseRating()
		.clickSave();
		
		
	}

}
